# Saad Paper 1.21.7 Setup

A small interactive installer for a personal Minecraft **Java Edition 1.21.7** Paper server on Ubuntu/Debian, including many Proot environments.

## Features

- Downloads a Java 21 runtime into the server folder (does not need system Java).
- Downloads the latest stable Paper build for Minecraft 1.21.7 from PaperMC.
- Prompts for server name, offline/cracked mode, minimum/maximum RAM, operator username, optional hostname, and EULA agreement.
- Enables whitelist and sets a small-player performance configuration.
- Attempts to install OnePlayerSleep from Hangar.
- No systemd requirement; includes a `start.sh`-style runner.

## Run

```bash
git clone YOUR_REPOSITORY_URL paper-setup
cd paper-setup
bash setup.sh
```

The setup script downloads the server to `~/paper-1.21.7` and starts it.

## Friends and whitelist

After server startup, use the server console:

```text
whitelist add FRIEND_JAVA_USERNAME
whitelist add ANOTHER_FRIEND
```

If you left the operator username blank, grant yourself operator access in the console:

```text
op YOUR_JAVA_USERNAME
whitelist add YOUR_JAVA_USERNAME
```

## Connect from your PC

The default Java port is TCP `25565`. Check the RDP provider firewall and host networking: Proot shares the host network and cannot independently open a provider firewall/NAT port.

The server prints a public IPv4 lookup result only if you run this command yourself:

```bash
curl -4 https://api.ipify.org
```

Then connect from Minecraft Java Edition using `PUBLIC_IP:25565`.

### Custom hostname

A hostname is not an IP rename. You must own/control a domain and create an `A` DNS record pointing at the RDP's public IPv4 address. If the IP changes, update the DNS record. If inbound TCP 25565 is blocked, use a suitable TCP tunnel or ask the RDP provider to open it.

## Security

- `online-mode=true` is recommended. If you choose offline/cracked mode, the server does not verify Minecraft account identity. Keep the whitelist enabled, never give OP to unknown users, and understand that usernames can be impersonated.
- Only expose TCP 25565, not SSH/RDP or other ports.
- Agree to the Minecraft EULA only after reading it: https://aka.ms/MinecraftEULA
- Back up the `world`, `world_nether`, `world_the_end`, and server configuration files before making changes.

## Proot notes

Proot is not full system root. It can run Java processes, but cannot independently change host firewall rules or bypass the RDP provider's NAT. The server stops if the host/session is terminated by the provider. `tmux` can keep it running after disconnecting from a terminal, if installed.
